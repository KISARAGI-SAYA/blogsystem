package com.xja.cvs.service;

import com.xja.cvs.pojo.Role;

import java.util.List;

/**
 * className:RoleService
 * description:
 * author:学佳澳教育
 * date:2025/3/6 10:47
 * version:1.0
 */
public interface RoleService {

    //查询全部角色
    public List<Role> queryAllRoles();

    //验证指定角色编码是否存在
    Role queryRoleByCode(String code);

    //添加角色记录
    int  insertRole(Role role);

    //根据角色编号 查询角色信息
    Role queryRoleById(Integer roleid);

    //修改角色信息操作
    int updateRole(Role role);

    //删除角色信息操作
    int deleteRoleById(Integer roleid);
}
