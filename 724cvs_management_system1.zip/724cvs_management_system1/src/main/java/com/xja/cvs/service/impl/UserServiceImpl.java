package com.xja.cvs.service.impl;

import com.xja.cvs.mapper.UserMapper;
import com.xja.cvs.pojo.User;
import com.xja.cvs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * className:UserServiceImpl
 * description:
 * author:学佳澳教育
 * date:2025/3/5 16:15
 * version:1.0
 */
@Service
public class UserServiceImpl implements UserService {

   //属性
    @Autowired
    private UserMapper userMapper;

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }


    /**
     * 从控制器传递进来账号和密码，查询数据库
     * @param account   账户
     * @param password  密码
     * @return 如果账号和密码正确，则返回指定的user对象，反之，返回null
     */
    @Override
    public User queryUserByAccountAndPassword(String account, String password) {
        //声明user对象，作用：充当方法的返回值
        User user = null;
        //逻辑判断
        if (account != null && !"".equals(account)){
            if (password != null && !"".equals(password)){
                //调用持久层接口对象
                try {
                    user = userMapper.selectUserByAccountAndPassword(account, password);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return user;
    }


    /**
     * 修改用户密码的方法
     * @param id   需要修改密码的账户的编号
     * @param newPassword  新密码
     * @return 如果操作成功，则返回1，反之，返回0
     */
    @Override
    public int updatePassword(Integer id, String newPassword) {
        int n = 0;
        if (id>0 && id != null){
            if (newPassword != null && !"".equals(newPassword)){
                try {
                    n = userMapper.modifyPassword(id, newPassword);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return n;
    }

    /**
     * 根据指定条件查询所有用户信息
     * @param realName   真实姓名
     * @param roleId     角色编号
     * @return  如果两个参数都是空，则默认查询全部用户信息，反之，则根据条件查询用户信息
     */
    @Override
    public List<User> queryAllUsers(String realName, Integer roleId) {
        List<User> userList = new ArrayList<>(); // 元素个数为0的空集合  并不是null
        try {
            userList = userMapper.selectAllUsers(realName, roleId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userList;
    }

    /**
     * 根据用户输入的账号，进行判断，数据库表中是否存在重复的账号
     * @param account  用户输入的账号名称
     * @return 如果返回user不是null，说明账号已经存在，反之，账号可以使用
     */
    @Override
    public User queryUserByAccount(String account) {
        User user = null;
        if (account  != null && !"".equals(account)){
            try {
                user = userMapper.selectUserByAccount(account);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return user;
    }

    /**
     * 向数据库添加一条用户信息
     * @param user  从form表单当中，自动生成一个user对象
     * @return 如果操作成功，则返回1，反之，返回0
     */
    @Override
    public int insertUser(User user) {
        int n = 0;
        if (user != null){
            try {
                n = userMapper.addUser(user);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }


    /**
     * 根据指定编号查询用户信息
     * @param userid  用户编号
     * @return 如果该编号存在，则返回user对象，反之返回null
     */
    @Override
    public User queryUserById(Integer userid) {
        //声明user对象，作用：充当方法的返回值
        User user = null;
        //逻辑判断
        if (userid != null && userid >0 ){

            //调用持久层接口对象
            try {
                user = userMapper.selectUserById(userid);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return user;
    }


    /**
     * 修改指定用户信息
     * @param user 用户对象
     * @return 如果操作成功，则返回1，反之返回0
     */
    @Override
    public int updateUserInfo(User user) {
        int n = 0;
        if (user != null){
            try {
                n = userMapper.modifyUser(user);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }

    /**
     * 根据指定编号删除用户信息
     * @param userid  指定用户编号
     * @return
     */
    @Override
    public int deleteUserById(Integer userid) {
        int n = 0;
        if (userid != null && userid > 0 ){
            try {
                n = userMapper.removeUserById(userid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }
}
