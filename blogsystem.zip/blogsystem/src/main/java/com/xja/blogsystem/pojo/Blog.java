package com.xja.blogsystem.pojo;

public class Blog {
}
