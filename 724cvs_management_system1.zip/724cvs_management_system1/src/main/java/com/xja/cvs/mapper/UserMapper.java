package com.xja.cvs.mapper;

import com.xja.cvs.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * className:UserMapper
 * description:
 * author:学佳澳教育
 * date:2025/3/5 14:25
 * version:1.0
 */
@Repository
public interface UserMapper {

    //根据账号和密码查询用户信息，对应登录操作
    public User selectUserByAccountAndPassword(
            @Param("account") String account,
            @Param("password") String password) throws Exception;

    //修改密码操作
    public int modifyPassword( @Param("id")Integer id,
                               @Param("newPassword")String newPassword) throws Exception;

    //如果两个参数的值都为空，则默认查询全部，反之，如果任何一个参数都有值，则进行带条件查询
    public List<User> selectAllUsers(@Param("realName")String realName,
                                     @Param("roleId")Integer roleId) throws Exception;

    //根据输入的账号查询指定用户
    User selectUserByAccount(@Param("account") String account) throws Exception;

    //添加用户记录
    int addUser(User user);

    //依据用户编号查询用户记录信息
    User selectUserById(@Param("userid")Integer userid);

    //修改用户操作
    int modifyUser(User user);

    //根据编号删除用户信息
    int removeUserById(@Param("userid")Integer userid);
}
