package com.xja.blogsystem.mapper;

public interface UserMapper {
}
