package com.xja.cvs.service.impl;

import com.xja.cvs.mapper.RoleMapper;
import com.xja.cvs.pojo.Role;
import com.xja.cvs.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * className:RoleServiceImpl
 * description:
 * author:学佳澳教育
 * date:2025/3/6 10:48
 * version:1.0
 */
@Service("roleService")
public class RoleServiceImpl implements RoleService {

    //属性
    @Autowired
    private RoleMapper roleMapper;

    public void setRoleMapper(RoleMapper roleMapper) {
        this.roleMapper = roleMapper;
    }


    /**
     * 通过业务层接口对象，查询t_sys_role表中所有的记录
     * @return 以List集合的方式，返回表中所有记录
     */
    @Override
    public List<Role> queryAllRoles() {
        List<Role> roleList = new ArrayList<>();
        //直接调用持久层接口
        try {
            roleList = roleMapper.selectAllRoles();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return roleList;
    }


    /**
     * 根据用户输入的角色编码，验证数据库表中是否存在
     * @param code  控制器层传递进来的角色编码
     * @return 如果指定的角色编码存在于数据库表，则返回role对象，反之，返回null
     */
    @Override
    public Role queryRoleByCode(String code) {
        Role role = null;
        if (code != null && !"".equals(code)){
            try {
                role =  roleMapper.selectRoleByCode(code);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return role;
    }


    /**
     * 添加角色记录
     * @param role  角色对象
     * @return  如果添加成功，则返回1，反之返回0
     */

    @Override
    public int insertRole(Role role) {
        int n = 0;
        if (role != null){
            try {
                n = roleMapper.addRole(role);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }


    /**
     * 根据角色编号查询角色对象信息
     * @param roleid  角色编号
     * @return  如果该角色编号存在则返回role对象，反之返回null
     */
    @Override
    public Role queryRoleById(Integer roleid) {
        Role role = null;
        if (roleid != null && roleid > 0 ){
            try {
                role = roleMapper.selectRoleById(roleid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return role;
    }


    /**
     * 修改角色信息操作
     * @param role  要修改的角色对象
     * @return  如果操作成功，则返回1，反之返回0
     */
    @Override
    public int updateRole(Role role) {
        int n = 0;
        if (role != null){
            try {
                n = roleMapper.modifyRole(role);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }

    /**
     * 根据角色编号进行删除操作
     * @param roleid  要删除角色的编号
     * @return 如果删除成功，则返回1，反之，返回0
     */
    @Override
    public int deleteRoleById(Integer roleid) {
        int n = 0;
        if (roleid != null && roleid > 0){
            try {
                n = roleMapper.removeRoleById(roleid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return n;
    }
}
