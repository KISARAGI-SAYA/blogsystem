package com.xja.cvs.web.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import com.xja.cvs.pojo.Resource;
import com.xja.cvs.pojo.Role;
import com.xja.cvs.pojo.User;
import com.xja.cvs.service.RoleService;
import com.xja.cvs.service.UserService;
import com.xja.cvs.util.JSONFileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * className:UserController
 * description:
 * author:学佳澳教育
 * date:2025/3/5 16:22
 * version:1.0
 */
@Controller
@RequestMapping("/sys/user")
public class UserController {

    //属性
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;


    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * 1.实现登录操作
     * @param account   账户   从login.jsp页面获取账户信息
     * @param password  密码   同上
     * @param session
     * @return 如果用户输入的账号密码正确，则跳转到frame.jsp主页面，反之跳转到login.jsp页面
     */
    @RequestMapping("/login")
    public String login(String account, String password, HttpSession session){
        //调用业务层接口对象
        User user = userService.queryUserByAccountAndPassword(account, password);

        //根据返回user对象的值，进行跳转页面
        if (user != null){
            //说明账号密码正确，应该跳转到主页面frame.jsp
            //需要把当前user对象， ，缓存到session作用域
            session.setAttribute("user",user);
            return "redirect:/jsp/frame.jsp";
        }
            //账号密码错误  跳转到login.jsp页面
            session.setAttribute("loginError","账号密码错误，请重新输入");
            return "forward:/jsp/login.jsp";
    }

    /**
     * 2.实现退出功能
     * @param session  session会话对象
     * @return 退出之后，重定向到login.jsp页面
     */
    @RequestMapping("/logout")
    public String logout(HttpSession session){
        //session对象调用方法  含义:清空作用域缓存的所有数据
        session.invalidate();
        return "redirect:/jsp/login.jsp";
    }

    /**
     * 3.检查用户输入的旧密码是否正确
     * @param oldPassword  js文件中ajax传递的用户输入的旧密码
     * @param session   session会话对象   作用:从session作用域中获取user对象信息
     * @param response  响应对象  作用：通过该参数获取打印输出流，向页面响应结果
     * @throws IOException
     */
    @RequestMapping("/checkOldPwd")
    @ResponseBody
    public  Map<String,String> checkOldPwd(String oldPassword,HttpSession session,HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=utf-8");
          //1.session作用域当中，获取缓存的User对象
        User user = (User) session.getAttribute("user");
        //2.定义K-V ,Map集合
        Map<String,String> map = new HashMap<>();
        map.put("result","error");
        //3.做一些判断
        if (user == null){
            //当前用户session过期，请重新登录
            map.put("result","sessionerror");
        }else{
            //针对用户输入的旧密码进行判断
            if (user.getPassword().equals(oldPassword)){
                map.put("result","true");
            }else{
                map.put("result","false");
            }
        }
        return map;
    }


    /**
     * 4.实现修改密码操作的方法
     * @param id    从form表单当中获取的当前登录用户的id
     * @param newPassword 用户输入的新密码
     * @return 如果修改成功，则跳转到登陆页面，否则，请求转发到修改密码的页面，并且给出相关提示信息
     */
    @RequestMapping("/savePassword")
    public String savePassword(Integer id,String newPassword,HttpServletRequest request){
        //需要调用业务层
        int i = userService.updatePassword(id, newPassword);
        //做出判断，进行分支
        if (i>0){
            //修改成功，则重定向到登录页
            return "redirect:/jsp/login.jsp";
        }
        //修改失败，应该跳转到修改页 并且给出相关提示信息
        request.setAttribute("updatePwdError","修改密码失败!");
        return "forward:/jsp/sysUser/updatePassword.jsp";
    }


    /**
     * 5.根据指定的条件进行查询用户信息
     * @param queryRealName  需要查询的用户真实姓名  默认值为空
     * @param queryRoleId   需要查询的用户的角色编号  默认值为0
     * @param pageNum       分页时需要显示的页码，默认为第一页
     * @param pageSize      分页时需要显示每页多条件记录，默认为5条记录
     * @param request      请求对象，为跳转list.jsp页面传递数据  例如： userList roleList 等等
     * @return
     */
    @RequestMapping("/findAllUsers")
    public String findAllUsers(
            @RequestParam(defaultValue = "") String queryRealName,
            @RequestParam(defaultValue = "0")Integer queryRoleId,
            @RequestParam(defaultValue = "1")Integer pageNum,
            @RequestParam(defaultValue = "5")Integer pageSize,
            HttpServletRequest request){

        //1.借助roleService接口对象，调用查询全部角色信息的方法
        List<Role> roleList = roleService.queryAllRoles();

        //2.查询之前，应该调用PageHelper  分页工具类
        PageHelper.startPage(pageNum,pageSize);

        //3.借助userService 调用方法查询用户信息
        List<User> userList = userService.queryAllUsers(queryRealName, queryRoleId);

        //4.使用PageInfo类   作用：封装了分页的相关数据的类  例如：总页数  当前页码 等等
        PageInfo<User> pageInfo = new PageInfo<>(userList);

        System.out.println("-----------------pageInfo分页相关数据----------------------");
        System.out.println("共记录数:"+pageInfo.getTotal());
        System.out.println("总页数:"+pageInfo.getPages());
        System.out.println("当前页码:"+pageInfo.getPageNum());
        System.out.println("每页显示的记录条数:"+pageInfo.getPageSize());
        System.out.println("-----------------pageInfo分页相关数据----------------------");

        long totalCount = pageInfo.getTotal();
        int totalPageCount = pageInfo.getPages();
        int currentPageNo =  pageInfo.getPageNum();



        request.setAttribute("roleList",roleList);
        request.setAttribute("userList",userList);
        request.setAttribute("totalPageCount",totalPageCount);
        request.setAttribute("totalCount",totalCount);
        request.setAttribute("currentPageNo",currentPageNo);
        request.setAttribute("pageInfo",pageInfo);
        request.setAttribute("queryRealName",queryRealName);
        request.setAttribute("queryRoleId",queryRoleId);

        return "forward:/jsp/sysUser/list.jsp";
    }

    /**
     * 6.验证用户输入的账号是否存在重复
     * @param account   用户输入的账号
     * @param response  响应对象
     * @return 以json格式数据响应给ajax前端
     */
    @RequestMapping("/userExist")
    @ResponseBody
    public Map<String,Integer> userExist(String account,HttpServletResponse response){
        response.setContentType("application/json;charset=utf-8");
        //定义map集合
        Map<String,Integer> hashMap = new HashMap<>();
        //初始化第一个元素
        hashMap.put("exist",-1);
        //调用业务层
        User user =  userService.queryUserByAccount(account);
        //进行判断
        if (user != null){
            //说明用户输入的账号已经存在
            hashMap.put("exist",1);
        }else{
            //说明用户输入的账号不存在  可以进行添加
            hashMap.put("exist",0);
        }
        return hashMap;
    }


    /**
     * 7.添加用户信息操作
     * @param user   借助form表单，会自动封装成一个user对象
     * @param idPic  证件照
     * @param workPic 工作照
     * @param request 请求对象
     * @return 如果添加成功，则跳转到查询全部用户的方法上，进而显示list.jsp页面
     *         否则，跳转到add.jsp页面，并且给出相关的提示信息
     */
    @RequestMapping("/addUser")
   public String addUser(User user,
                         MultipartFile idPic,
                         MultipartFile workPic,
                         HttpServletRequest request)throws Exception{

        //1.需要设置文件上传之后的路径
        String path =  request.getServletContext().getRealPath("/")+ "statics/upload_img/";
        String path2 =  request.getServletContext().getRealPath("/")+ "files/";
        System.out.println("------------------------------------");
        System.out.println(path);
        System.out.println(path2);
        File newFile = new File(path);
        if (!newFile.exists()){
            newFile.mkdirs();
            System.out.println("创建目录成功!");
        }
        System.out.println("------------------------------------");


        //2.获取用户上传文件的名称 例如： car1.png
        String idPicName = idPic.getOriginalFilename(); // 获取证件照的原始图片名称
        String workPicName = workPic.getOriginalFilename(); // 获取工作照的原始图片名称

        //3.读取files.json文件中的文件名称
        String json = JSONFileUtils.readFile(path2 + "files.json");

        //4.想办法把String类型的json  转换成List集合
        List<Resource> list = new ArrayList<>();//空集合
        ObjectMapper mapper = new ObjectMapper();
        //判断json字符串是否为空
        if (json.length() > 0 ){
            list = mapper.readValue(json,new TypeReference<List<Resource>>() {});
            //借助循环语句，判断上传的文名称是否有重复的
            for (Resource resource : list) {
                //如果上传的文件在files.json文件中有同名文件，将当前上传的文件重命名，以避免重名
                if (idPicName.equals(resource.getName())) {
                    //以.进行分割字符串  最终分割成两个子字符串
                    String[] split = idPicName.split("\\.");
                    //例如： 数组 元素：  {car1,png}
                    // fdsf.car.fdsfds(1).png
                    // car1.png
                    idPicName = split[split.length-2] + "(1)." + split[split.length-1];
                }
                if (workPicName.equals(resource.getName())) {
                    //以.进行分割字符串  最终分割成两个子字符串
                    String[] split = workPicName.split("\\.");
                    //例如： 数组 元素：  {car1,png}
                    // fdsf.car.fdsfds(1).png
                    // car1.png
                    workPicName = split[split.length-2] + "(1)." + split[split.length-1];
                }
            }

        }

        //5.完成文件上传
        // 文件保存的全路径
        String idPicPath = path + idPicName;
        String worPicPath = path + workPicName;
        // 保存上传的文件
        idPic.transferTo(new File(idPicPath));
        workPic.transferTo(new File(worPicPath));
        list.add(new Resource(idPicName));
        list.add(new Resource(workPicName));
        json = mapper.writeValueAsString(list); //将集合中转换成json
        //将上传文件的名称保存在files.json文件中
        JSONFileUtils.writeFile(json, path2 + "files.json");

        System.out.println("---------------------------");
        System.out.println("User="+user); //发现 imgURL属性为空
        User login_user = (User) request.getSession().getAttribute("user");
        user.setCreatedUserId(login_user.getId());
        user.setCreatedTime(new Date());
        System.out.println("---------------------------");

        String idPicPath2 = request.getContextPath()+"/statics/upload_img/"+idPicName;
        String workPicPath2 = request.getContextPath()+"/statics/upload_img/"+workPicName;
        System.out.println(idPicPath2);
        System.out.println(workPicPath2);
        System.out.println("---------------------------");
        user.setIdPicPath(idPicPath2);
        user.setWorkPicPath(workPicPath2);
        user.setAge(18);
        System.out.println(user);



        //调用业务层
       int n =  userService.insertUser(user);
       //判断
       if (n>0){
           //添加成功
           return "redirect:/sys/user/findAllUsers";
       }else{
           //添加失败
           request.setAttribute("error","添加失败!");
           return "forward:/jsp/sysUser/add.jsp";
       }


   }


    /**
     * 8.根据前端页面传递的userid查看用户信息
     * @param userid    用户编号
     * @param request
     * @return 如果真实存在该编号的用户，则把用户对象信息传递给view.jsp页面进行显示，
     *         反之，应该跳转到list.jsp页面，并且给出相关提示信息
     */
    @RequestMapping("/viewUser")
   public String viewUser(Integer userid,  HttpServletRequest request){


        //调用业务层
       User user =  userService.queryUserById(userid);
        System.out.println("------------------------");
        System.out.println(user);
        System.out.println("------------------------");
        //判断
        if (user != null){
            //查询成功  跳转到view.jsp页面
            request.setAttribute("sysUser",user);
            return "forward:/jsp/sysUser/view.jsp";
        }
        //查询失败
        request.setAttribute("errorInfo","查询失败!");
        return "forward:/jsp/sysUser/list.jsp";

    }

    /**
     * 9. 根据前端页面传递的用户编号，进行预修改操作
     *    先把我们需要修改的用户对象信息，映射到update.jsp
     * @param userid  用户编号
     * @param request
     * @return
     */
    @RequestMapping("/toUpdate")
    public String toUpdate(Integer userid,HttpServletRequest request){
        //调用业务层 --  根据用户编号，查询当前的用户对象信息
        User user = userService.queryUserById(userid);
        //借助域对象request 调用方法进行传递数据
        request.setAttribute("sysUser",user);
        //页面跳转
        return "forward:/jsp/sysUser/update.jsp";
    }


    /**
     * 10.修改指定用户信息操作
     * @param user    依据SpringMVC框架，自动把页面当中form表单的表单项的值，自动封装user对象
     * @param request
     * @return
     */
    @RequestMapping("/updateUser")
    public String updateUser(User user,HttpServletRequest request){
       int n =  userService.updateUserInfo(user);
       if (n>0){
           //修改成功
           return "redirect:/sys/user/findAllUsers";
       }
       request.setAttribute("updateUserError","修改失败");
        return "forward:/jsp/sysUser/update.jsp";
    }

    /**
     * 11. 根据指定的用户编号，进行删除记录
     * @Param userid  指定的用户编号
     * @Param request
     * @return
     */
    @RequestMapping("/delUser")
    @ResponseBody
    public Map<String,String> delUser(Integer userid,HttpServletResponse response) {
        response.setContentType("application/json;charset=utf-8");
        Map<String,String> hashMap = new HashMap<>();
        //为集合的属性进行初始化值
        hashMap.put("delResult","notexist");
        //调用业务层
        int n =  userService.deleteUserById(userid);
        //判断
        if (n>0){
            hashMap.put("delResult","true");
        }else{
            hashMap.put("delResult","false");
        }
        return hashMap;
    }
}
