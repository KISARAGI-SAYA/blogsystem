package com.xja.cvs.web.interceptor;

import com.xja.cvs.pojo.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * className:LoginInterceptor
 * description:
 * author:学佳澳教育
 * date:2025/3/7 9:31
 * version:1.0
 */
public class LoginInterceptor implements HandlerInterceptor {

    //重写预处理方法
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //依据规则进行拦截请求
        //获取浏览器发送的请求路径
        String uri =  request.getRequestURI();
        //如果uri路径包括：login  logout   register
        if (uri.indexOf("/login") >= 0){
            return true; //放行
        }
        if (uri.indexOf("/logout") >= 0){
            return true; //放行
        }
        if (uri.indexOf("/statics") >= 0){
            return true; //放行
        }
        //从session作用域当中，进行获取缓存的user对象
        User user  = (User) request.getSession().getAttribute("user");
        if (user  != null){
            //用户是登录成功的
            return true;
        }

        request.setAttribute("loginError","您尚未登录，请先登录!");
        request.getRequestDispatcher("/jsp/login.jsp").forward(request,response);
        return false;
    }
}
