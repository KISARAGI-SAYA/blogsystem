package com.xja.blogsystem.service;

public interface BlogService {
}
