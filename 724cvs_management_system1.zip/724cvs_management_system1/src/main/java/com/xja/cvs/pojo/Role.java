package com.xja.cvs.pojo;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * create table t_sys_role(
 *    id BIGINT primary key auto_increment comment '角色表编号  主键自增',
 * 	 code varchar(255) not null comment '角色编码 非空',
 * 	 roleName varchar(255) not null comment '角色名称 非空',
 * 	 createdUserId int comment '创建者编号',
 * 	 createdTime datetime default NOW() comment '创建时间',
 * 	 updatedUserId int comment '修改者编号',
 * 	 updatedTime dateTime comment '修改时间'
 * );
 */
@Data
public class Role implements Serializable {
    private Integer id;
    private String code;
    private String roleName;
    private Integer createdUserId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdTime;
    private Integer updatedUserId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date updatedTime;


}
