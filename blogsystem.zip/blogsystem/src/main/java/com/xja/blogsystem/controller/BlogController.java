package com.xja.blogsystem.controller;

public class BlogController {
}
