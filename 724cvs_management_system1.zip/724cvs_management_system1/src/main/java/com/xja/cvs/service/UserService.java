package com.xja.cvs.service;

import com.xja.cvs.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * className:UserService
 * description:
 * author:学佳澳教育
 * date:2025/3/5 16:14
 * version:1.0
 */
public interface UserService {

    //根据账号和密码查询用户信息，对应登录操作
    public User queryUserByAccountAndPassword(String account,String password) ;

    //修改用户的密码
    public int updatePassword(Integer id,String newPassword);

    //根据条件查询所有用户
    public List<User> queryAllUsers(String realName,Integer roleId);

    //根据账号进行等值查询
    User queryUserByAccount(String account);

    //添加用户信息
    int insertUser(User user);

    //根据id查询用户信息
    User queryUserById(Integer userid);

    //修改用户操作
    int updateUserInfo(User user);

    //根据编号删除用户信息
    int deleteUserById(Integer userid);
}
