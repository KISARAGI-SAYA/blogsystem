package com.xja.cvs.web.controller;

import com.google.gson.Gson;
import com.xja.cvs.pojo.Role;
import com.xja.cvs.pojo.User;
import com.xja.cvs.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * className:RoleController
 * description:
 * author:学佳澳教育
 * date:2025/3/6 10:52
 * version:1.0
 */
@Controller
@RequestMapping("/sys/role")
public class RoleController {

    //属性
    @Autowired
    private RoleService roleService;

    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

    /**
     * 1.在list.jsp页面显示所有角色信息
     * @param request
     * @return 以List集合形式传递给list.jsp页面
     */
    @RequestMapping("/findAllRoles")
    public String findAllRoles(HttpServletRequest request){
        //调用业务层
        List<Role> roleList = roleService.queryAllRoles();
        //想办法把数据库中获取的所有角色记录，传递给页面
        request.setAttribute("roleList",roleList);
        return "forward:/jsp/sysRole/list.jsp";
    }

    /**
     * 2.验证用户输入的角色编码是否存在重复
     * @param code      用户输入的角色编码
     * @param response  响应对象  作用：创建PintWriter，响应结果给前端页面
     * @throws IOException
     */
    @RequestMapping("/codeExist")
   public Map<String,Integer> codeExist(String code, HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        //调用业务层
       Role role =  roleService.queryRoleByCode(code);
       //定义一个map集合
        Map<String,Integer> hashMap = new HashMap<>();
        //为集合添加一个元素，
        hashMap.put("exist",-1);
       //针对role对象进行判断
       if (role != null){
           //说明用户输入的角色编码在t_sys_role表中存在
           hashMap.put("exist",1);
       }else{
           hashMap.put("exist",0);
       }
      return hashMap;
    }

    /**
     * 3.添加角色操作
     * @param role    springmvc框架会默认把form表单的数据，封装成role对象
     * @param request 请求对象
     * @return  如果添加成功，则跳转到/sys/user/findAllRoles控制器方法以便显示表中所有的角色记录，
     *          反之，携带提示语句请求转发到add.jsp页面
     */
    @RequestMapping("/toAdd")
    public String toAdd(Role role,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        role.setCreatedUserId(user.getId());
        role.setCreatedTime(new Date());
        //1.调用业务层
       int i =  roleService.insertRole(role);
       //2.做一个判断
        if (i>0){
            return "redirect:/sys/role/findAllRoles";
        }else{
           request.setAttribute("addRoleError","添加失败!");
           return "forward:/jsp/sysRole/add.jsp";
        }
    }

    /**
     * 4.修改操作之前的准备
     * @param roleid  角色编号
     * @param request 请求对象
     * @return  根据id查询所得的role对象，传递给update.jsp页面
     */
    @RequestMapping("/toUpdate")
    public String toUpdate(Integer roleid,HttpServletRequest request){
        //调用业务层 --  根据角色编号，查询当前的角色对象信息
        Role role = roleService.queryRoleById(roleid);
        //借助域对象request 调用方法进行传递数据
        request.setAttribute("sysRole",role);
        //页面跳转
        return "forward:/jsp/sysRole/update.jsp";
    }

    /**
     * 5.修改角色信息操作
     * @param role    角色对象  springmvc框架，根据form表单，自动封装成一个角色对象
     * @param request  请求对象
     * @return 如果修改成功则跳转到查询全部角色的控制器方法，进而渲染到list.jsp页面
     *         反之，则跳转到update.jsp页面，并且给出相关提示信息
     */
    @RequestMapping("/updateRole")
    public String updateRole(Role role,HttpServletRequest request){
        //1.借助域对象，获取session作用域当中缓存的user对象
        User user = (User) request.getSession().getAttribute("user");
        role.setUpdatedUserId(user.getId());
        role.setUpdatedTime(new Date());

        System.out.println("---->"+role);
        //2.调用业务层
        int i = roleService.updateRole(role);

        //3.判断
        if (i>0){
            return "redirect:/sys/role/findAllRoles";
        }else{
            request.setAttribute("updateError","修改失败!");
            return "forward:/jsp/sysRole/update.jsp";
        }


    }

    /**
     * 6.删除指定编号的角色记录
     * @param roleid    从前端页面传递的角色编号
     * @param response  响应对象
     */
    @RequestMapping("/delRole")
    public Map<String,String> delRole(Integer roleid, HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        //调用业务层
        int n =   roleService.deleteRoleById(roleid);
        //定义map集合
        Map<String,String> hashMap = new HashMap<>();
        hashMap.put("delResult","notexist");
        //进行判断
        if (n > 0){
            //删除成功
            hashMap.put("delResult","true");
        }else{
            //删除失败
            hashMap.put("delResult","false");
        }
        return hashMap;
    }

    /**
     * 7.在ass.jsp页面上，获取所有的角色列表进行渲染
     * @param response
     * @return
     */
    @RequestMapping("/simpleList")
    @ResponseBody
    public List<Role> simpleList(HttpServletResponse response){
        //响应的格式
        response.setContentType("application/json;charset=utf-8");
        //调用业务层
        List<Role> roleList = roleService.queryAllRoles();
        return roleList;
    }
}
