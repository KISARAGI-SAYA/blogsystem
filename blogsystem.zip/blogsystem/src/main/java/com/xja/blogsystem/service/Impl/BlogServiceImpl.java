package com.xja.blogsystem.service.Impl;

public class BlogServiceImpl {
}
