package com.xja.blogsystem.pojo;

public class User {
}
