package com.xja.blogsystem.mapper;


import com.xja.blogsystem.pojo.Blog;

import java.util.List;

public interface BlogMapper {
    /**
     * 查询所有博客列表
     * @return 博客列表
     */
    List<Blog> getAllBlogs();

    /**
     * 根据博客 ID 查询博客
     * @param id 博客 ID
     * @return 博客对象
     */
    Blog getBlogById(int id);
}