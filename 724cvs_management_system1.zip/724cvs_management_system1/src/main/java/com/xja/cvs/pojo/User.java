package com.xja.cvs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * className:User
 * description:
 *   CREATE TABLE `t_sys_user`  (
 *   `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
 *   `account` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '账号',
 *   `realName` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '真实姓名',
 *   `password` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户密码',
 *   `sex` int(0) NULL DEFAULT 1 COMMENT '性别（1:女、 2:男）',
 *   `age` int(0) NULL DEFAULT 18,
 *   `birthday` date NULL DEFAULT NULL COMMENT '出生日期',
 *   `phone` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '手机',
 *   `address` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址',
 *   `roleId` bigint(0) NULL DEFAULT NULL COMMENT '用户角色（取自角色表-角色id）',
 *   `createdUserId` bigint(0) NULL DEFAULT NULL COMMENT '创建者（userId）',
 *   `createdTime` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
 *   `updatedUserId` bigint(0) NULL DEFAULT NULL COMMENT '更新者（userId）',
 *   `updatedTime` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
 *   `idPicPath` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '上传个人证件照存储路径',
 *   `workPicPath` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '上传个人工作证照片存储路径',
 *   PRIMARY KEY (`id`) USING BTREE,
 *   INDEX `FK_ROLE_ID`(`roleId`) USING BTREE,
 *   CONSTRAINT `FK_ROLE_ID` FOREIGN KEY (`roleId`) REFERENCES `t_sys_role` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
 * )
 * author:学佳澳教育
 * date:2025/3/5 15:59
 * version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User  {

    private Integer id;
    private String account;
    private String realName;
    private String password;
    private Integer sex;
    private Integer age;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;
    private String phone;
    private String address;
    private Integer roleId;
    private Integer createdUserId;
    private Integer updatedUserId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date updatedTime;
    private String idPicPath;
    private String workPicPath;
    //关联角色对象
    private Role role;

}
