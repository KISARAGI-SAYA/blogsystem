package com.xja.blogsystem.service;

public interface UserService {
}
