package com.xja.cvs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * className:Resource
 * description:
 *    此类 是针对files.json文件  记录文件上传时，文件名称
 * author:学佳澳教育
 * date:2024/11/2 9:38
 * version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Resource {
    private String name;      //name属性表示文件名称
}
