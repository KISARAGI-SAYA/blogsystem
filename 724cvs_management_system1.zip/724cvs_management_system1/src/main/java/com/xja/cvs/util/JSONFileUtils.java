package com.xja.cvs.util;

import org.apache.commons.io.IOUtils;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * className:JSONFileUtils
 * description:
 *    此工具类，针对文件的读与写操作
 * author:学佳澳教育
 * date:2024/11/2 9:41
 * version:1.0
 */
public class JSONFileUtils {
    /**
     * 该方法针对指定路径下的文件，进行读取操作
     * @param filepath  文件路径
     * @return
     * @throws Exception
     */
    public static String readFile(String filepath) throws Exception {
        //文件字节输入流对象
        FileInputStream fis = new FileInputStream(filepath);
        return IOUtils.toString(fis);
    }

    /**
     * 针对指定文件进行写入的操作
     * @param data
     * @param filepath
     * @throws Exception
     */
    public static void writeFile(String data,String filepath)  throws Exception {
        //字节输出流对象
        FileOutputStream fos = new FileOutputStream(filepath);
        IOUtils.write(data,fos); }

}
