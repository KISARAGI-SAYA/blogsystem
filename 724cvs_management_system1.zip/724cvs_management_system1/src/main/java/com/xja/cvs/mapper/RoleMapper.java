package com.xja.cvs.mapper;

import com.xja.cvs.pojo.Role;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * className:RoleMapper
 * description:
 * author:学佳澳教育
 * date:2025/3/6 10:43
 * version:1.0
 */
@Repository
public interface RoleMapper {

    //默认查询全部角色信息
    public List<Role> selectAllRoles() throws Exception;

    //验证指定角色编码是否存在于t_sys_role表中
   public  Role selectRoleByCode(@Param("code") String code)throws Exception;

   //添加角色信息到数据库表
   public int addRole(Role role) throws Exception;

   //根据指定的编号查询
    Role selectRoleById(@Param("roleid")Integer roleid)throws Exception;

    //修改指定角色信息
    int modifyRole(Role role) throws Exception;

    //依据指定的编号删除角色记录
    int removeRoleById(@Param("roleid")Integer roleid);
}
